let bgcolor = document.getElementById("bgColorInput");
let fontcolor = document.getElementById("fontColorInput");
let fontsize = document.getElementById("fontSizeInput");
let fontweight = document.getElementById("fontWeightInput");
let paddingg = document.getElementById("paddingInput");
let borderradius = document.getElementById("borderRadiusInput");
let custombutton = document.getElementById("customButton");

function applr() {
    let bgvalue = bgcolor.value;
    let fontvalue = fontcolor.value;
    let fontsinput = fontsize.value;
    let fontwinpu = fontweight.value;
    let paddinginput = paddingg.value;
    let borderradiusinput = borderradius.value;

    custombutton.style.backgroundColor = bgvalue;
    custombutton.style.color = fontvalue;
    custombutton.style.fontSize = fontsinput;
    custombutton.style.fontWeight = fontwinpu;
    custombutton.style.padding = paddinginput;
    custombutton.style.borderRadius = borderradiusinput;

}